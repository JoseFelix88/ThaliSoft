# ReporteJasperReport
Ejemplo de cómo crear reportes con jasperReport e iReport sin conexión a una base de datos.
